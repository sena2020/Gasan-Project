package dao;

public class FoodDao {
	private static FoodDao instance = new FoodDao();
	private FoodDao() {}
	public static FoodDao getInstance() {
		return instance;
	}
}
