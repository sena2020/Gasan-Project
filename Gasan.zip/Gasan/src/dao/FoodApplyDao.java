package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import model.ArticleFoodApply;

public class FoodApplyDao {
	private static FoodApplyDao instance = new FoodApplyDao();

	private FoodApplyDao() {
	}

	public static FoodApplyDao getInstance() {
		return instance;
	}

	public ArticleFoodApply select(Connection conn, int applyId) {
		ArticleFoodApply foodApply = null;
		String sql = "select * from foodApply where applyId = ?";

		try (PreparedStatement pst = conn.prepareStatement(sql)) {
			pst.setInt(1, applyId);
			try (ResultSet rs = pst.executeQuery()) {
				if (rs.next()) {
					String loginId = rs.getString("loginId");
					String title = rs.getString("title");
					String content = rs.getString("content");

					foodApply = new ArticleFoodApply(applyId, loginId, title, content);
				} else {
					throw new RuntimeException();
				}
			}
		} catch (SQLException e) {
			throw new RuntimeException(e);
		}

		return foodApply;
	}

	public void update(Connection conn, ArticleFoodApply foodApply) {
		String sql = "update foodApply set loginId = ?, title = ?, content = ? where applyId = ?";
		try (PreparedStatement pst = conn.prepareStatement(sql)) {
			pst.setString(1, foodApply.getLoginId());
			pst.setString(2, foodApply.getTitle());
			pst.setString(3, foodApply.getContent());
			pst.setInt(4, foodApply.getApplyId());

			pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public void delete(Connection conn, int applyId) {
		String sql = "delete from foodApply where applyId = ?";
		try (PreparedStatement pst = conn.prepareStatement(sql)) {
			pst.setInt(1, applyId);

			pst.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

	public ArticleFoodApply insert(Connection conn, ArticleFoodApply articleFood) throws SQLException {

		String sql = "insert into foodapply(loginId,title,content) values(?,?,?)";

		try (PreparedStatement pst = conn.prepareStatement(sql); Statement st = conn.createStatement()) {
			pst.setString(1, articleFood.getLoginId());
			pst.setString(2, articleFood.getTitle());
			pst.setString(3, articleFood.getContent()); // 왜??

			pst.executeUpdate(); // ???

			return articleFood;
		}
		// 왜 여기있던 null이 이동?? ㅇㅅㅇ??
	}
}
