package service;

public class CommentEnrollService {
	private static CommentEnrollService instance = new CommentEnrollService();
	private CommentEnrollService() {}
	public static CommentEnrollService getInstance() {
		return instance;
	}	
}
