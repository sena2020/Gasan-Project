package service;

public class FoodSearchService {
	private static FoodSearchService instance = new FoodSearchService();
	private FoodSearchService() {}
	public static FoodSearchService getInstance() {
		return instance;
	}		
}
