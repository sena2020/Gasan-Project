package service;

public class CommentDeleteService {
	private static CommentDeleteService instance = new CommentDeleteService();
	private CommentDeleteService() {}
	public static CommentDeleteService getInstance() {
		return instance;
	}	
}
