package handler;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LogoutHandler implements CommandHandler{
	@Override
	public String process(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		
		// 세션을 날리고 리다이렉트로 돌려줌.
		
		HttpSession session = req.getSession(false); //HttpServletRequest 에 있는 getSession메소드를 쓰는 것.
		
		if(session!=null) {
			session.invalidate();
		}
	    //리다이렉트로 돌려줌.
		resp.sendRedirect(req.getContextPath()+"/index.jsp");
		
		return null;
	}

	
}
