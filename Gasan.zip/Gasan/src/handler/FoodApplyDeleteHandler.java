package handler;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.FoodApplyDeleteService;

public class FoodApplyDeleteHandler implements CommandHandler{

	@Override
	public String process(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		if(req.getMethod().equals("GET")) {
			processForm(req, resp);
		} else if (req.getMethod().equals("POST")) {
			processSubmit(req, resp);
		} else {
			resp.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return null;
		}
		return null;
	}

	private String processSubmit(HttpServletRequest req, HttpServletResponse resp) {
		return null;
	}

	private String processForm(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		FoodApplyDeleteService deleteService = FoodApplyDeleteService.getInstance();
		int applyId = Integer.parseInt(req.getParameter("applyId"));
		
		deleteService.delete(applyId);
		
		resp.sendRedirect(req.getContextPath());
		return null;
	}
}
