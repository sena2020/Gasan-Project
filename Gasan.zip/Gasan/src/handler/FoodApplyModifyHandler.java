package handler;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import model.ArticleFoodApply;
import model.AuthUser;
import service.FoodApplyModifyService;

public class FoodApplyModifyHandler implements CommandHandler{

	@Override
	public String process(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		if(req.getMethod().equals("GET")) {
			return processForm(req, resp);
		} else if (req.getMethod().equals("POST")) {
			return processSubmit(req, resp);
		} else {
			resp.setStatus(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
			return null;
		}
	}

	private String processSubmit(HttpServletRequest req, HttpServletResponse resp) throws IOException{
		FoodApplyModifyService applyModifyService = FoodApplyModifyService.getInstance();
		
		int applyId = Integer.parseInt(req.getParameter("applyId"));
		AuthUser authUser = (AuthUser)req.getSession().getAttribute("authUser");
		String title = req.getParameter("title");
		String content = req.getParameter("content");
		
		ArticleFoodApply foodApply = new ArticleFoodApply(applyId, authUser.getLoginId(), title, content);
		System.out.println(foodApply);
		applyModifyService.modify(foodApply);
		PrintWriter pw = resp.getWriter();
		pw.print("<script>alert('수정을 완료하였습니다.')</script>");
		resp.sendRedirect(req.getContextPath() + "/index.jsp");
		return null;
	}

	private String processForm(HttpServletRequest req, HttpServletResponse resp) {
		FoodApplyModifyService applyModifyService = FoodApplyModifyService.getInstance();
		
		String noStr = req.getParameter("no");
		
		ArticleFoodApply foodApply = applyModifyService.getArticle(Integer.parseInt(noStr));
		req.setAttribute("foodApply", foodApply);
		return "/WEB-INF/view/foodApplyModifyForm.jsp";
	}
}
